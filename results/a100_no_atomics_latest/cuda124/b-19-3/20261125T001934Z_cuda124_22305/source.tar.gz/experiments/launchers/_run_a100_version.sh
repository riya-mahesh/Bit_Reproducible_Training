#!/usr/bin/env bash
# Full A100 protocol using an environment prepared by prepare_a100_cuda*.sh.
set -euo pipefail
SELF=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")
ROOT=$(cd "$(dirname "$SELF")/../.." && pwd)
TAG=${1:-}; shift || true
source "$(dirname "$SELF")/_a100_version_config.sh"
a100_select_version "$TAG" "$ROOT"
ARGS=("$@")
BACKGROUND=0; INSIDE=0; DRY=0; NCU=1; ALLOW_BUSY=0; REPEATS=5
while (($#)); do
  case "$1" in
    --background) BACKGROUND=1; shift;;
    --foreground) BACKGROUND=0; shift;;
    --container) INSIDE=1; shift;;
    --dry-run) DRY=1; shift;;
    --skip-ncu) NCU=0; shift;;
    --allow-busy) ALLOW_BUSY=1; shift;;
    --repeats) (($# >= 2)) || exit 2; REPEATS=$2; shift 2;;
    -h|--help)
      echo 'Usage: bash experiments/launchers/a100_cuda124.sh (or a100_cuda126.sh, a100_cuda130.sh)'
      echo '  [--background] [--repeats N] [--skip-ncu] [--allow-busy] [--dry-run]'
      echo 'Run on the allocated A100 host, outside Singularity. Default: five baseline repeats, all profiling.'
      exit 0;;
    *) echo "Unknown option: $1"; exit 2;;
  esac
done
[[ "$REPEATS" =~ ^[1-9][0-9]*$ ]] || { echo 'Invalid repeat count'; exit 2; }
VENV="$ENV_DIR"
RESULTS="$ROOT/results/a100_no_atomics/$TAG"
if ((DRY)); then
  printf 'Configuration: %s\nImage: %s\nVenv: %s\nResults/archives: %s/<hostname>/<run-id>\n' "$TAG" "$IMAGE" "$VENV" "$RESULTS"
  echo "Compiler/toolkit: $TOOLKIT_PATH; expected torch $TORCH, CUDA $CUDA_VERSION"
  echo "Full training runs: $((34 + 3 * REPEATS)); smoke: 1; Nsight requested: $NCU (4 captures)"
  exit 0
fi
if ((INSIDE == 0)); then
  [[ -z ${SINGULARITY_CONTAINER:-}${APPTAINER_CONTAINER:-} ]] || { echo 'Exit Singularity; launch from the allocated A100 host.'; exit 2; }
  [[ -f "$IMAGE" && -f "$VENV/pyvenv.cfg" ]] || { echo "Missing image/environment. First run prepare_a100_$TAG.sh"; exit 2; }
  if [[ "$TAG" == cuda124 && ! -f "$TOOLKIT_PATH/.setup_complete" ]]; then
    echo 'CUDA 12.4 toolkit is not prepared. Run prepare_a100_cuda124.sh first.'; exit 2
  fi
  if ((BACKGROUND)); then
    mkdir -p "$ROOT/results/a100_no_atomics/launch_logs"
    LOG="$ROOT/results/a100_no_atomics/launch_logs/${TAG}_$(date -u +%Y%m%dT%H%M%SZ)_$$.log"
    nohup bash "$SELF" "$TAG" ${ARGS[@]+"${ARGS[@]}"} --foreground > "$LOG" 2>&1 < /dev/null &
    echo "Background PID: $!"; echo "Log: $LOG"; printf 'Watch: tail -f %q\n' "$LOG"
    exit 0
  fi
  visibility=()
  if [[ ${CUDA_VISIBLE_DEVICES+x} ]]; then visibility=(--env "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"); fi
  # Preserve absolute paths used by the venv and its compiled RepDL extension.
  exec singularity exec --cleanenv --nv ${visibility[@]+"${visibility[@]}"} \
    --bind "$ROOT:$ROOT" --pwd "$ROOT" "$IMAGE" \
    /bin/bash "$SELF" "$TAG" ${ARGS[@]+"${ARGS[@]}"} --foreground --container
fi
[[ -n ${SINGULARITY_CONTAINER:-}${APPTAINER_CONTAINER:-} ]] || { echo 'Internal container invocation required'; exit 2; }
[[ -x "$VENV/bin/python3" ]] || { echo "Missing venv Python: $VENV"; exit 2; }
if [[ "$TAG" == cuda124 ]]; then
  [[ -f "$TOOLKIT_PATH/.setup_complete" && -x "$TOOLKIT_PATH/bin/nvcc" ]] || { echo 'Private CUDA 12.4 toolkit missing'; exit 2; }
fi
a100_activate_toolkit
export PATH="$VENV/bin:$PATH" PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME REPRO_BUILD REPRO_CPU_ONLY
selection=${CUDA_VISIBLE_DEVICES-0}; gpu=${selection%%,*}
[[ -n "$gpu" && "$gpu" != -1 ]] || { echo 'No allocated GPU visible'; exit 1; }
mkdir -p "$ROOT/results/a100_no_atomics/locks" "$WORK/locks"
exec 9> "$ROOT/results/a100_no_atomics/locks/$(hostname -s)_gpu${gpu}.lock"
flock -n 9 || { echo 'Another launcher is using this GPU; run the versions sequentially.'; exit 1; }
exec 8> "$WORK/locks/$TAG.lock"
flock -n 8 || { echo 'This environment is being installed or used by another run'; exit 1; }
pids=$(nvidia-smi -i "$gpu" --query-compute-apps=pid --format=csv,noheader,nounits)
if [[ -n "$pids" ]]; then
  echo "Existing GPU processes: $pids"
  ((ALLOW_BUSY)) || { echo 'Stop your keep-alive GPU workload before benchmarking; do not stop other users processes.'; exit 1; }
fi
export BASELINE_REPEATS=$REPEATS A100_CONTAINER_IMAGE="$IMAGE"
export A100_RESULTS_ROOT="$RESULTS" A100_BUILD_ROOT="$WORK/build/$TAG"
export RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)_${TAG}_$$"
flags=(); ((NCU)) || flags=(--skip-ncu)
bash "$ROOT/experiments/run_a100_no_atomics.sh" --config "$TAG" \
  --python "$VENV/bin/python3" ${flags[@]+"${flags[@]}"}
