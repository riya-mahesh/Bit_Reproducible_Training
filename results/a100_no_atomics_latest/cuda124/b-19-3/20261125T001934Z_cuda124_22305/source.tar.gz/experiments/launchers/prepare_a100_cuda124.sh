#!/usr/bin/env bash
set -euo pipefail
exec bash "$(dirname "${BASH_SOURCE[0]}")/_prepare_a100_env.sh" cuda124 "$@"
