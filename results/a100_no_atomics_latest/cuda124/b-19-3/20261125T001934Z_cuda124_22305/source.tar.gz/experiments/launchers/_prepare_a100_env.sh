#!/usr/bin/env bash
# Install inside the matching container at a stable host/container absolute path.
# No old venv, numerical source, or experiment result is modified.
set -euo pipefail
SELF=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")
ROOT=$(cd "$(dirname "$SELF")/../.." && pwd)
TAG=${1:-}; shift || true
source "$(dirname "$SELF")/_a100_version_config.sh"
a100_select_version "$TAG" "$ROOT"
if [[ ${1:-} == --dry-run && $# == 1 ]]; then
  printf 'Image: %s\nPython: /usr/bin/python3 (3.12)\nEnvironment: %s\nPyTorch: %s+%s\nRepDL: acd95bb\n' "$IMAGE" "$ENV_DIR" "$TORCH" "$WHEEL"
  if [[ "$TAG" == cuda124 ]]; then echo "Compiler: private CUDA 12.4.1 toolkit at $WORK/toolkits/cuda-12.4.1 (download/install first)"; fi
  echo 'Environment preparation only; no MNIST or profiling runs.'
  exit 0
fi
if [[ $# == 0 ]]; then
  [[ -z ${SINGULARITY_CONTAINER:-}${APPTAINER_CONTAINER:-} ]] || { echo 'Exit Singularity first; run this setup script on the allocated A100 host.'; exit 2; }
  [[ -f "$IMAGE" ]] || { echo "Missing image: $IMAGE"; exit 2; }
  mkdir -p "$WORK/logs"
  LOG="$WORK/logs/prepare_${TAG}_$(date -u +%Y%m%dT%H%M%SZ)_$$.log"
  echo "Setup log: $LOG"
  df -h "$WORK"
  visibility=()
  if [[ ${CUDA_VISIBLE_DEVICES+x} ]]; then visibility=(--env "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"); fi
  singularity exec --cleanenv --nv ${visibility[@]+"${visibility[@]}"} \
    --bind "$ROOT:$ROOT" --pwd "$ROOT" "$IMAGE" \
    /bin/bash "$SELF" "$TAG" --container 2>&1 | tee "$LOG"
  exit 0
fi
[[ $# == 1 && $1 == --container && -n ${SINGULARITY_CONTAINER:-}${APPTAINER_CONTAINER:-} ]] || { echo 'Usage: prepare_a100_cuda124.sh, prepare_a100_cuda126.sh or prepare_a100_cuda130.sh [--dry-run]'; exit 2; }
export PATH=/usr/local/cuda/bin:/usr/bin:/bin
export CUDA_HOME=/usr/local/cuda CC=/usr/bin/gcc CXX=/usr/bin/g++
export LDSHARED='/usr/bin/g++ -shared -pthread -B/usr/bin/'
export LD_PRELOAD=$(/usr/bin/g++ -print-file-name=libstdc++.so.6)
export TORCH_CUDA_ARCH_LIST=8.0 MAX_JOBS=4 PIP_NO_CACHE_DIR=1 PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME REPRO_BUILD REPRO_CPU_ONLY
command -v git >/dev/null
mkdir -p "$WORK/locks" "$WORK/tmp/$TAG"
exec 9> "$WORK/locks/$TAG.lock"
flock -n 9 || { echo "Another setup is using $TAG"; exit 1; }
export TMPDIR="$WORK/tmp/$TAG"
if [[ "$TAG" == cuda124 ]]; then
  # The site image provides Linux/Python; the active compiler and toolkit are 12.4.
  export CUDA_HOME="$TOOLKIT_PATH"
  if [[ ! -f "$CUDA_HOME/.setup_complete" ]]; then
    mkdir -p "$WORK/downloads" "$WORK/toolkits"
    INSTALLER="$WORK/downloads/cuda_12.4.1_550.54.15_linux.run"
    /usr/bin/python3 - "$INSTALLER" <<'PY'
import hashlib, os, pathlib, sys, urllib.request
p = pathlib.Path(sys.argv[1])
expected = 'afc99bab1d8c6579395d851d948ca3c1'
# Published NVIDIA checksum (integrity check, downloaded over HTTPS):
# https://developer.download.nvidia.com/compute/cuda/12.4.1/docs/sidebar/md5sum.txt
def valid(path):
    if not path.is_file(): return False
    h = hashlib.md5()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8*1024*1024), b''): h.update(b)
    return h.hexdigest() == expected
if not p.exists():
    partial = p.with_suffix(p.suffix + '.partial')
    print('Downloading NVIDIA CUDA 12.4.1 installer (several GB)...', flush=True)
    urllib.request.urlretrieve('https://developer.download.nvidia.com/compute/cuda/12.4.1/local_installers/' + p.name, partial)
    if not valid(partial): raise SystemExit('CUDA installer checksum mismatch; download not installed')
    os.replace(partial, p)
if not valid(p): raise SystemExit('Existing CUDA installer checksum mismatch; inspect downloads directory')
print('NVIDIA installer checksum verified', flush=True)
PY
    echo "Installing toolkit only at $CUDA_HOME; no driver installation."
    sh "$INSTALLER" --silent --toolkit --toolkitpath="$CUDA_HOME" \
      --defaultroot="$CUDA_HOME" --tmpdir="$TMPDIR"
    test -x "$CUDA_HOME/bin/nvcc"
    touch "$CUDA_HOME/.setup_complete"
  fi
  export PATH="$CUDA_HOME/bin:/usr/bin:/bin"
  # Keep Singularity's host driver injection; exclude the base image's 12.6 paths.
  export LD_LIBRARY_PATH="$CUDA_HOME/lib64:/.singularity.d/libs"
  printf 'extern "C" __global__ void setup_check() {}\n' > "$TMPDIR/setup_check.cu"
  "$CUDA_HOME/bin/nvcc" -arch=sm_80 -c "$TMPDIR/setup_check.cu" -o "$TMPDIR/setup_check.o"
fi
a100_activate_toolkit
nvcc --version
/usr/bin/python3 - "$CUDA_VERSION" <<'PY'
import re, subprocess, sys
assert sys.version_info[:2] == (3, 12), 'Expected container Python 3.12'
actual = re.search(r'release (\d+\.\d+)', subprocess.check_output(['nvcc','--version'], text=True)).group(1)
assert actual == sys.argv[1], (actual, sys.argv[1])
PY
# --without-pip works even when Ubuntu's ensurepip package is absent.
if [[ ! -f "$ENV_DIR/pyvenv.cfg" ]]; then
  /usr/bin/python3 -m venv --without-pip "$ENV_DIR"
fi
PY="$ENV_DIR/bin/python3"
"$PY" -c 'import sys; assert sys.version_info[:2] == (3,12); assert sys.prefix != sys.base_prefix'
if ! "$PY" -m pip --version; then
  if ! "$PY" -m ensurepip --upgrade; then
    /usr/bin/python3 - "$TMPDIR/get-pip.py" <<'PY'
import sys, urllib.request
urllib.request.urlretrieve('https://bootstrap.pypa.io/get-pip.py', sys.argv[1])
PY
    "$PY" "$TMPDIR/get-pip.py"
  fi
fi
export PATH="$ENV_DIR/bin:$PATH"
"$PY" -m pip install --upgrade pip wheel 'setuptools<70' ninja
"$PY" -m pip install "torch==$TORCH" "torchvision==$VISION" --index-url "https://download.pytorch.org/whl/$WHEEL"
"$PY" -m pip install numpy mpmath
# Import and allocate before building RepDL: detect partial or incompatible wheels.
"$PY" - "$TORCH" "$CUDA_VERSION" <<'PY'
import sys, torch
assert torch.__version__.split('+')[0] == sys.argv[1], torch.__version__
assert torch.version.cuda == sys.argv[2], torch.version.cuda
assert torch.cuda.is_available(), 'No allocated CUDA GPU is visible'
assert 'A100' in torch.cuda.get_device_name(0), torch.cuda.get_device_name(0)
print(torch.__version__, torch.version.cuda, torch.ones(1, device='cuda'))
PY
REPDL="$ENV_DIR/RepDL"
if [[ ! -d "$REPDL" ]]; then
  git clone https://github.com/microsoft/RepDL.git "$REPDL"
fi
if [[ -n $(git -C "$REPDL" status --porcelain --untracked-files=no) ]]; then
  echo "Local RepDL source edits found in $REPDL; refusing to replace them."; exit 1
fi
git -C "$REPDL" checkout --detach acd95bb
"$PY" -m pip install --no-build-isolation --force-reinstall --no-deps "$REPDL"
"$PY" -m pip check
"$PY" - "$TORCH" "$CUDA_VERSION" "$ENV_DIR/config" <<'PY'
import pathlib, sys, torch, repdl
assert torch.__version__.split('+')[0] == sys.argv[1]
assert torch.version.cuda == sys.argv[2]
print('PASS:', torch.__version__, torch.version.cuda, torch.cuda.get_device_name(0), repdl.__file__)
pathlib.Path(sys.argv[3]).write_text("CUDA_MODULE=''\nTORCH='%s'\nWHEEL='cu%s'\n" % (sys.argv[1], sys.argv[2].replace('.', '')))
PY
"$PY" -m pip freeze > "$ENV_DIR/packages.txt"
nvcc --version > "$ENV_DIR/nvcc.txt"
printf '%s\n' "$CUDA_HOME" > "$ENV_DIR/cuda_home.txt"
git -C "$REPDL" rev-parse HEAD > "$ENV_DIR/repdl_commit.txt"
echo "READY: $ENV_DIR"
echo 'Setup complete. This did not run training. Use this venv only inside its matching container.'
