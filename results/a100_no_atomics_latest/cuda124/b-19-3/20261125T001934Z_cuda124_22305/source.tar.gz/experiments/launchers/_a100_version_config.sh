#!/usr/bin/env bash
# Shared by setup and experiment launchers; paths stay identical in the container.
a100_select_version() {
  local tag=$1 root=$2
  case "$tag" in
    cuda124) CUDA_VERSION=12.4; TORCH=2.6.0; VISION=0.21.0; WHEEL=cu124
      IMAGE=/share/apps/images/cuda12.6.2-cudnn9.5.0-devel-ubuntu24.04.1.sif;;
    cuda126) CUDA_VERSION=12.6; TORCH=2.7.1; VISION=0.22.1; WHEEL=cu126
      IMAGE=/share/apps/images/cuda12.6.2-cudnn9.5.0-devel-ubuntu24.04.1.sif;;
    cuda130) CUDA_VERSION=13.0; TORCH=2.9.0; VISION=0.24.0; WHEEL=cu130
      IMAGE=/share/apps/images/cuda13.0.1-cudnn9.13.0-ubuntu-24.04.3.sif;;
    *) echo "Unsupported A100 version: $tag" >&2; return 2;;
  esac
  WORK="$root/experiment_workspace/a100_versions"
  ENV_DIR="$WORK/envs/$tag"
  TOOLKIT_PATH=/usr/local/cuda
  if [[ "$tag" == cuda124 ]]; then TOOLKIT_PATH="$WORK/toolkits/cuda-12.4.1"; fi
}

a100_activate_toolkit() {
  export CUDA_HOME="$TOOLKIT_PATH"
  # Private nvcc wins. The base image's tools provide a fallback ncu if needed.
  export PATH="$TOOLKIT_PATH/bin:/usr/local/cuda/bin:/usr/bin:/bin"
  if [[ "$TAG" == cuda124 ]]; then
    export LD_LIBRARY_PATH="$TOOLKIT_PATH/lib64:/.singularity.d/libs"
  fi
}
