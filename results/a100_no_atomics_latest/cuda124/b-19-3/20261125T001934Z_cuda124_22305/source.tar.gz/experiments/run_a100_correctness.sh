#!/usr/bin/env bash
# Standalone component tests, inside an allocated A100 CUDA development container.
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
PY=${REPRO_PYTHON:-python3}
DRY=0
usage() {
  cat <<'EOF'
Usage: bash experiments/run_a100_correctness.sh [--python /venv/bin/python3] [--dry-run]
Run INSIDE the CUDA development container on an allocated A100.
Builds the production kernels.cu translation unit and runs six standalone tests:
GEMM, sums, convolution, softmax/cross-entropy/exp/log, pooling/Adam, finite scan.
No RepDL, PyTorch extension build, MNIST download, benchmarks, or exhaustive sweep.
Python is used for source snapshots and metadata; PyTorch is optional metadata only.
Preserves CUDA_VISIBLE_DEVICES; uses GPU 0 within that visible set.
Results: repo/results/a100_correctness/<host>/<run-id>/ plus .tar.gz and SHA256.
Builds:  repo/build/a100_correctness/<host>/<run-id>/ (fresh; never overwritten).
A100_CORRECTNESS_RESULTS_ROOT and A100_CORRECTNESS_BUILD_ROOT override those roots.
RUN_ID overrides the UTC timestamp/PID run identifier. Results include failures.
Requires experiments/rerun_support.py from this repository. Run in foreground;
keep the GPU allocation and container alive until the final status is printed.
EOF
}
while (($#)); do
  case "$1" in
    --python) (($# >= 2)) || { usage; exit 2; }; PY=$2; shift 2 ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) usage; exit 2 ;;
  esac
done
if ((DRY)); then usage; echo 'Flags: -O3 -std=c++17 -arch=sm_80 --fmad=false -lineinfo; host contraction disabled'; exit 0; fi
command -v "$PY" >/dev/null || { echo "Python not found: $PY"; exit 2; }
command -v nvcc >/dev/null || { echo 'nvcc missing: enter the CUDA development container first.'; exit 2; }
command -v nvidia-smi >/dev/null || { echo 'nvidia-smi missing: enter the container with --nv.'; exit 2; }
[[ -f "$ROOT/experiments/rerun_support.py" ]] || { echo 'Missing experiments/rerun_support.py'; exit 2; }
[[ -x /usr/bin/g++ ]] || { echo 'Expected /usr/bin/g++ in the CUDA container'; exit 2; }
export CXX=/usr/bin/g++ CC=/usr/bin/gcc PYTHONDONTWRITEBYTECODE=1
CPP_RUNTIME=$(/usr/bin/g++ -print-file-name=libstdc++.so.6)
if [[ -f "$CPP_RUNTIME" ]]; then export LD_PRELOAD="$CPP_RUNTIME${LD_PRELOAD:+:$LD_PRELOAD}"; fi
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES-0}
HOST=$(hostname -s)
RUN_ID=${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)_$$}
[[ "$RUN_ID" =~ ^[A-Za-z0-9_-]+$ ]] || { echo 'Invalid RUN_ID'; exit 2; }
RESULTS=${A100_CORRECTNESS_RESULTS_ROOT:-$ROOT/results/a100_correctness}
BUILDS=${A100_CORRECTNESS_BUILD_ROOT:-$ROOT/build/a100_correctness}
mkdir -p "$RESULTS/$HOST" "$BUILDS/$HOST"
RESULTS=$(cd "$RESULTS/$HOST" && pwd)
BUILDS=$(cd "$BUILDS/$HOST" && pwd)
OUT="$RESULTS/$RUN_ID"
WORK="$BUILDS/$RUN_ID"
[[ ! -e "$OUT" && ! -e "$WORK" ]] || { echo 'Run ID already exists; choose a fresh RUN_ID.'; exit 2; }
mkdir "$OUT" "$WORK"
mkdir "$OUT/logs" "$OUT/environment" "$WORK/bin"
exec 3>&1
exec > "$OUT/runner.log" 2>&1
progress() { echo "$*"; echo "$*" >&3; }
FINISHED=0
FAILED=0
finish() {
  local rc=$?
  trap - EXIT
  if ((FINISHED == 0 || FAILED)); then rc=1; fi
  if ((rc)); then echo FAILED > "$OUT/status.txt"; else echo PASS > "$OUT/status.txt"; fi
  if tar -czf "$RESULTS/$RUN_ID.tar.gz" -C "$RESULTS" "$RUN_ID"; then
    if ! "$PY" - "$RESULTS/$RUN_ID.tar.gz" <<'PY'
import hashlib, pathlib, sys
p = pathlib.Path(sys.argv[1])
h = hashlib.sha256()
with p.open('rb') as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b''):
        h.update(chunk)
p.with_name(p.name + '.sha256').write_text(h.hexdigest() + '  ' + p.name + '\n')
PY
    then rc=1; echo FAILED > "$OUT/status.txt"; fi
  else rc=1; echo FAILED > "$OUT/status.txt"; fi
  progress "Status: $(cat "$OUT/status.txt")"
  progress "Logs: $OUT"
  progress "Archive: $RESULTS/$RUN_ID.tar.gz (check status.txt, not archive existence)"
  exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
echo RUNNING > "$OUT/status.txt"
: > "$OUT/status.tsv"
: > "$OUT/commands.log"
run() {
  local label=$1 rc=0; shift
  progress "$label"
  printf '%s: ' "$label" >> "$OUT/commands.log"
  printf '%q ' "$@" >> "$OUT/commands.log"
  printf '\n' >> "$OUT/commands.log"
  "$@" > "$OUT/logs/$label.log" 2>&1 || rc=$?
  printf '%s\t%s\n' "$label" "$rc" >> "$OUT/status.tsv"
  if ((rc)); then FAILED=1; progress "FAILED: $label (exit $rc); see $OUT/logs/$label.log"; tail -n 12 "$OUT/logs/$label.log" >&3; fi
  return "$rc"
}
progress "A100 component correctness: $OUT"
"$PY" "$ROOT/experiments/rerun_support.py" snapshot "$ROOT" "$WORK/source" "$OUT/source_manifest.json"
"$PY" - "$OUT/source_manifest.json" <<'PY'
import json, sys
bad = json.load(open(sys.argv[1]))['explicit_atomic_call_lines']
if bad:
    raise SystemExit('Explicit CUDA atomic-call candidates in source: ' + ', '.join(bad))
PY
SRC="$WORK/source"
tar -czf "$OUT/source.tar.gz" -C "$SRC" .
nvcc --version > "$OUT/environment/nvcc.txt"
/usr/bin/g++ --version > "$OUT/environment/compiler.txt"
nvidia-smi -q > "$OUT/environment/gpu.txt"
"$PY" - > "$OUT/environment/python.txt" <<'PY'
import os, platform, sys
print(sys.version)
print(platform.platform())
print('CUDA_VISIBLE_DEVICES=' + os.environ['CUDA_VISIBLE_DEVICES'])
try:
    import torch
    print('torch:', torch.__version__, 'wheel CUDA:', torch.version.cuda)
except ImportError:
    print('torch: unavailable (not required by these standalone tests)')
PY
FLAGS=(-O3 -std=c++17 -arch=sm_80 --fmad=false -lineinfo -ccbin /usr/bin/g++
  -Xcompiler=-fno-fast-math,-ffp-contract=off,-pthread
  -I"$SRC/repro_gemm_cuda" -I"$SRC/repro_sum_cuda" -I"$SRC/repro_math_cuda"
  -I"$SRC/repro_conv_cuda" -I"$SRC/repro_nn_cuda" -I"$SRC/repro_torch/src")
cat > "$OUT/environment/device_check.cu" <<'CU'
#include <cuda_runtime.h>
#include <cstdio>
#include <cstring>
int main() {
    cudaDeviceProp p{};
    cudaError_t e = cudaGetDeviceProperties(&p, 0);
    if (e != cudaSuccess) { std::fprintf(stderr, "%s\n", cudaGetErrorString(e)); return 1; }
    std::printf("Visible GPU 0: %s; sm_%d%d\n", p.name, p.major, p.minor);
    return p.major == 8 && p.minor == 0 && std::strstr(p.name, "A100") ? 0 : 2;
}
CU
run build_device_check nvcc "${FLAGS[@]}" "$OUT/environment/device_check.cu" -o "$WORK/bin/device_check"
run device_check "$WORK/bin/device_check"
# Exactly the combined CUDA translation unit used by the PyTorch GPU extension.
run build_kernels nvcc "${FLAGS[@]}" -c "$SRC/repro_torch/src/kernels.cu" -o "$WORK/bin/kernels.o"
TESTS=(repro_gemm_cuda/test_repro_gemm.cu repro_sum_cuda/test_repro_sum.cu
  repro_conv_cuda/test_repro_conv.cu repro_math_cuda/test_repro_softmax.cu
  repro_nn_cuda/test_repro_nn.cu repro_torch/src/test_repro_scan.cu)
for source in "${TESTS[@]}"; do
  name=$(basename "$source" .cu)
  if run "build_$name" nvcc "${FLAGS[@]}" "$SRC/$source" "$WORK/bin/kernels.o" -o "$WORK/bin/$name"; then
    run "$name" "$WORK/bin/$name" || true
  else
    printf '%s\tSKIPPED_BUILD_FAILED\n' "$name" >> "$OUT/status.tsv"
  fi
done
"$PY" - "$WORK/bin" "$OUT/binary_manifest.json" <<'PY'
import hashlib, json, pathlib, sys
files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(pathlib.Path(sys.argv[1]).iterdir()) if p.is_file()}
pathlib.Path(sys.argv[2]).write_text(json.dumps(files, indent=2) + '\n')
PY
FINISHED=1
exit "$FAILED"
